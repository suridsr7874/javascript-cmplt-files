// Variable Declaration
let empName = 'Wilson';
console.log("Emp Name : " + empName); // Old way ES5
console.log(`Emp Name : ${empName}`); // New Way Es6 (back tick)



